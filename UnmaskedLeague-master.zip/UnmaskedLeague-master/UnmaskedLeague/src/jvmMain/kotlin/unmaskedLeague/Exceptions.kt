package unmaskedLeague

class LeagueNotFoundException(message: String) : Exception(message)
