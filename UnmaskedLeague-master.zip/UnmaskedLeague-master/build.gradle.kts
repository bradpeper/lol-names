allprojects {
    group = "io.github.xbaank"
    version = "1.1.11"
}
